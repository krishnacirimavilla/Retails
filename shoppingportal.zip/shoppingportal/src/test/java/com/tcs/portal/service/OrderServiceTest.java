package com.tcs.portal.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.tcs.portal.exception.ProductNotFoundException;
import com.tcs.portal.model.Product;
import com.tcs.portal.services.IOrderService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:/context/applicationcontext.xml")
public class OrderServiceTest {

	@Autowired
	private IOrderService orderService;

	@Test
	public void testProductNull() throws ParseException, ProductNotFoundException {
		List<Product> prod = null;
		orderService.getDiscountPrice(prod, "Krishna", "EMP", "23-02-2015");
		org.junit.Assert.assertNull(prod);
	}

	@Test
	public void testProductNotNull() throws ParseException, ProductNotFoundException {
		Product prod = new Product();
		prod.setPid("p101");
		prod.setPname("SAMSUNG-TV");
		prod.setQty(1);
		prod.setPrice(1000.00);
		prod.setProductType("Electronics");

		List<Product> prodall = new ArrayList<Product>();
		prodall.add(prod);

		Double discountAmt = orderService.getDiscountPrice(prodall, "Krishna",
				"EMP", "23-02-2015");
		org.junit.Assert.assertNotNull(discountAmt);
	}

	@Test
	public void testGetDiscountPrice() throws ProductNotFoundException,
			ParseException {

		Product prod = new Product();
		prod.setPid("p101");
		prod.setPname("SAMSUNG-TV");
		prod.setQty(1);
		prod.setPrice(1000.00);
		prod.setProductType("Electronics");

		Product prod1 = new Product();
		prod1.setPid("p102");
		prod1.setPname("WashingMachine");
		prod1.setQty(1);
		prod1.setPrice(2000.00);
		prod1.setProductType("Electronics");

		Product prod2 = new Product();
		prod2.setPid("p102");
		prod2.setPname("Millets");
		prod2.setQty(1);
		prod2.setPrice(12000.00);
		prod2.setProductType("grocery");

		List<Product> prodall = new ArrayList<Product>();
		prodall.add(prod);
		prodall.add(prod1);
		prodall.add(prod2);
		Double discountAmt = orderService.getDiscountPrice(prodall, "Krishna",
				"EMP", "23-02-2015");
		org.junit.Assert.assertEquals(900.00, discountAmt, 00);
	}
	
	

}
