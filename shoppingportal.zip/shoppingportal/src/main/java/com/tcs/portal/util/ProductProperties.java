package com.tcs.portal.util;

import java.util.Properties;

import org.apache.commons.lang.StringUtils;

/**
 * @author 1024066
 * 
 * This class is used to get the properties file.
 *
 */
public class ProductProperties {

		Properties properties;

		public void setProperties(Properties properties) {
			this.properties = properties;
		}

		public String getProperty(String key) {
			if (StringUtils.isNotBlank(key)) {
				return properties.getProperty(key);
			} else {
				return null;
			}
		}

	}


