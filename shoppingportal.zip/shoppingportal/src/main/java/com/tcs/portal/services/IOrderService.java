package com.tcs.portal.services;

import java.text.ParseException;
import java.util.List;

import com.tcs.portal.exception.ProductNotFoundException;
import com.tcs.portal.model.Product;

public interface IOrderService {
	//public Map<String,Product> addProduct(Product p);
	//public Collection<Product> getCartDetails();	
	//public int productCount();
	/*public double getCartPrice();*/
	public Double getDiscountPrice(List<Product> p,String userName,String role,String doj) throws ParseException,ProductNotFoundException;
    
}
