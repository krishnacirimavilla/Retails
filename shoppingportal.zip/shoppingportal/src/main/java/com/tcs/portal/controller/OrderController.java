package com.tcs.portal.controller;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class OrderController {

	private static final Logger logger = Logger.getLogger(OrderController.class);
	
}
