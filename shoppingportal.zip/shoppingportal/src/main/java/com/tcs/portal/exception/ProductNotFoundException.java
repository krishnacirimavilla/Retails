package com.tcs.portal.exception;

import org.springframework.stereotype.Component;

@Component
public class ProductNotFoundException extends Exception {
    
	
	public ProductNotFoundException(){}
    public ProductNotFoundException(String msg){
        super(msg);
    }
}
