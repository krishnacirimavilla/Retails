package com.tcs.portal.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Period;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.portal.controller.OrderController;
import com.tcs.portal.exception.ProductNotFoundException;
import com.tcs.portal.model.Product;
import com.tcs.portal.services.IOrderService;
import com.tcs.portal.util.DateUtil;
import com.tcs.portal.util.ProductProperties;

@Service("orderService")
public class OrderServiceImpl  implements IOrderService {

	
	@Autowired
	private  ProductProperties productProperties;
	
	private static final Logger logger = Logger.getLogger(OrderController.class);
	
	public String userName;
	public String role;
	public String doj;
    private Map<String,List<Product>> map;
    SimpleDateFormat dojfrmt = new SimpleDateFormat("dd-MM-yyyy");
	
	
 
  
  /**
   * This  method returns the discount price for product based on the user.
 * @return price 
 * @throws ParseException
 * @throws ProductNotFoundException 
 */
public Double getDiscountPrice(List<Product> p,String userName,String role,String doj) throws ParseException, ProductNotFoundException{	   
	map = new HashMap<String,List<Product>>();	
	Double discountPrice = 0.0d;
	Double totalPrice = 0.0d;	
	Double totalPrice_without_grocery = 0.0d;
	Double netPayment= 0.0d;	
	Long prodCnt=0L;
	    try {			
			
			map.put(userName,p);

			for (Map.Entry<String, List<Product>> entry : map.entrySet()) {
              
				List<Product> product = entry.getValue();
				
             for(int index=0;index<product.size();index++){
				if (!product.get(index).getProductType().equalsIgnoreCase(productProperties.getProperty("product.type.grosery")) && product.get(index).getPrice() != null) {                     
					
					if (role.equalsIgnoreCase(productProperties.getProperty("product.employee"))) {
                         						
						discountPrice += product.get(index).getPrice() * Double.parseDouble(productProperties.getProperty("product.employee.discount"));

					} else if (role.equalsIgnoreCase(productProperties.getProperty("product.affiliate"))) {

						discountPrice += product.get(index).getPrice() * Double.parseDouble(productProperties.getProperty("product.affiliate.discount"));

					} else if (role.equalsIgnoreCase(productProperties.getProperty("product.customer"))
							&& getCustDOJ(doj).getYears() >= Integer.parseInt(productProperties.getProperty("product.customer.doj"))) {

						discountPrice += product.get(index).getPrice() * Double.parseDouble(productProperties.getProperty("product.customer.discount"));

					} else {
						discountPrice += product.get(index).getPrice() * Double.parseDouble(productProperties.getProperty("product.bill.discount"));
					}
					totalPrice_without_grocery+=product.get(index).getPrice();
				}				
				totalPrice+=product.get(index).getPrice();
				prodCnt+=product.get(index).getQty();
				
				
             }
             netPayment=totalPrice-discountPrice;

			} 			
		 
		} catch (Exception e) {
			logger.error("Failed while calculating Product Discount:" + e.getMessage());
			throw new ProductNotFoundException(e.getMessage());
		}
	    logger.info("Discount Price:"+discountPrice);	
	    System.out.println("User Name:"+userName);	    
	    System.out.println("NO of Products:"+prodCnt);
	    System.out.println("Total Price:"+totalPrice);
	    System.out.println("Discount Price:"+discountPrice);	    
	    System.out.println("Total Price without grocery:"+totalPrice_without_grocery);
	    System.out.println("Net Payment by customer:"+netPayment);
	    return discountPrice;
}




/** Returns 
 * @param doj
 * @return Customer Date of Joining year compared with current date.
 * @throws ParseException
 */
private Period getCustDOJ(String doj) throws ParseException {
	Date date = dojfrmt.parse(doj);
	Period period = DateUtil.getDateDiff(date);
	return period;
}

/**
 * This  method returns the total price for product based on the user.
* @return price  
* @throws ProductNotFoundException 
*//*
public double getCartPrice()  {
double price = 0;
try {
	price = 0.0d;
	Iterator<Product> iterator = getCartDetails().iterator();
	while(iterator.hasNext()){
	  price+= ((Product) iterator.next()).getPrice();
	}
} catch (Exception e) {
	//logger.error("Failed while calculating Product Discount:" + e.getMessage());
	//throw new ProductNotFoundException(e.getMessage());
}
return price;
}*/





}