package com.tcs.portal.util;

import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	// Convert Date to Calendar
		public static synchronized Calendar dateToCalendar(Date date) {

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			return calendar;

		}

		public static synchronized Period getDateDiff(Date date) {

			Calendar calendar = DateUtil.dateToCalendar(date);
			LocalDate inputdate = LocalDate.of(calendar.get(calendar.YEAR),
					calendar.get(calendar.MONTH) + 1,
					calendar.get(calendar.DAY_OF_MONTH));
			LocalDate currentDate = LocalDate.now();
			Period diff = Period.between(inputdate, currentDate);
			return diff;
		}
	
}
